# PornHub Checker
- Mass PornHub Accounts Checker v0.9 (Uploaded on 19/02/2019 01.20 IST)

## For Educational Purposes Only!!
#### I Will Not be Responsible for Any Kind of Problems That Arise due to Unfair Usage!!
###### P.S. You Know What I Mean! xD

## v0.9 Release Notes!!
### IMPORTANT
* THIS IS A BETA TEST.
* PLEASE REPORT ANY BUGS OR SUGGESTIONS ON TELEGRAM OR GITHUB.
* Report any Bugs at https://t.me/VoldemortCommunity (Telegram)

## Changelog

### v0.9

- v0.9 Beta is Out Now!!
- Colourised Output!! Hits are now GREEN!! 
- Functionality to Save Hits!!
-  Automatically Check for Updates Before Each Run!!
- Added Setup & Dependency Installation on First Run!!
- Username:Password Combo Type is also Supported!
- Some Under-The-Hood Changes..UI Tweaks & Performance Upgrades!!


### Regards,
### @voldemort1912!🖖🏻

## HOW TO USE!!
* Open a Terminal & Run `pkg update && pkg upgrade && pkg install git && pkg install curl`
* Next, Run `git clone https://github.com/VoldemortCommunity/PornHubChecker`
* Navigate to the Newly Created SpotifyChecker Directory using `cd PornHubChecker`
* The Program has Now been Installed and Can be Run!!
* To Start the Program Use `php checker`
* Follow the Instructions!
* Make Sure you move the Combo File to the Same Directory as the Checker!
* Peace!🖖🏻

## To-Do

* You Tell Me. Suggestions → https://t.me/VoldemortCommunity (Telegram)

### Issues?

* Report Them on GitHub!!
* Contact Support : https://t.me/VoldemortCommunity (Telegram)

### Feature Requests & Feedback

* Contact Me : https://t.me/VoldemortCommunity (Telegram)
* Mail Me : Voldemort1912@hackermail.com

#### Have Questions?
* Join the Conversation at https://t.me/VoldemortCommunity !!
* DM me @Voldemort1912 !!
* DM me on Telegram https://t.me/hewhomustn0tbenamed !!
